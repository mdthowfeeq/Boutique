/**
 * ============================================================
 * LUXE BOUTIQUE - WISHLIST (localStorage & Wishlist Page UI)
 * ============================================================
 */

const WISHLIST_KEY = 'luxe_wishlist';

function getWishlist() {
  const data = localStorage.getItem(WISHLIST_KEY);
  return data ? JSON.parse(data) : [];
}

function saveWishlist(wishlist) {
  localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  updateWishlistBadge();
}

function updateWishlistBadge() {
  const wishlist = getWishlist();
  const badges = document.querySelectorAll('.wishlist-badge');
  badges.forEach(b => {
    b.textContent = wishlist.length;
  });
}

function isWishlisted(productId) {
  const wishlist = getWishlist();
  return wishlist.some(item => Number(item.id) === Number(productId));
}

function toggleWishlist(productId) {
  const products = window.boutiqueProducts || [];
  const product = products.find(p => p.id === Number(productId));
  if (!product) return;

  const wishlist = getWishlist();
  const existingIndex = wishlist.findIndex(item => Number(item.id) === Number(productId));

  if (existingIndex > -1) {
    wishlist.splice(existingIndex, 1);
    if (window.showToast) {
      showToast(`Removed "${product.name}" from wishlist`, 'info');
    }
  } else {
    wishlist.push({
      id: product.id,
      name: product.name,
      price: product.price,
      oldPrice: product.oldPrice,
      image: product.image,
      category: product.category,
      rating: product.rating
    });
    if (window.showToast) {
      showToast(`Saved "${product.name}" to wishlist`, 'wishlist');
    }
  }

  saveWishlist(wishlist);

  // Update heart buttons on current page if any
  const heartBtns = document.querySelectorAll(`.wishlist-btn-[data-id="${productId}"]`);
  heartBtns.forEach(btn => {
    if (isWishlisted(productId)) {
      btn.classList.add('active-heart');
      btn.innerHTML = '💖';
    } else {
      btn.classList.remove('active-heart');
      btn.innerHTML = '♡';
    }
  });

  if (document.getElementById('wishlist-items-container')) {
    renderWishlistPage();
  }
}

function removeFromWishlist(productId) {
  let wishlist = getWishlist();
  const index = wishlist.findIndex(item => Number(item.id) === Number(productId));
  if (index > -1) {
    const removedName = wishlist[index].name;
    wishlist.splice(index, 1);
    saveWishlist(wishlist);
    if (window.showToast) {
      showToast(`Removed "${removedName}" from wishlist`, 'info');
    }
    renderWishlistPage();
  }
}

function moveWishlistToCart(productId) {
  if (window.addToCart) {
    addToCart(productId, 1);
  }
  removeFromWishlist(productId);
}

// Render Wishlist Page
function renderWishlistPage() {
  const container = document.getElementById('wishlist-items-container');
  const emptyStateEl = document.getElementById('wishlist-empty-state');

  if (!container) return; // Not on wishlist page

  const wishlist = getWishlist();

  if (wishlist.length === 0) {
    container.style.display = 'none';
    if (emptyStateEl) emptyStateEl.style.display = 'block';
    return;
  }

  container.style.display = 'grid';
  if (emptyStateEl) emptyStateEl.style.display = 'none';

  container.innerHTML = '';

  wishlist.forEach(item => {
    const card = document.createElement('div');
    card.className = 'product-card animate-fade-in';
    card.innerHTML = `
      <div class="product-img-wrap">
        <a href="product.html?id=${item.id}">
          <img src="${item.image}" alt="${item.name}" loading="lazy" />
        </a>
      </div>
      <div class="product-info">
        <span class="product-cat">${item.category}</span>
        <h3 class="product-name"><a href="product.html?id=${item.id}">${item.name}</a></h3>
        <div class="product-price-wrap">
          <span class="current-price">₹${Number(item.price).toFixed(2)}</span>
          ${item.oldPrice ? `<span class="old-price">₹${Number(item.oldPrice).toFixed(2)}</span>` : ''}
        </div>
        <div style="display: flex; gap: 10px; margin-top: auto;">
          <button class="btn-add-cart" onclick="moveWishlistToCart(${item.id})">
            🛒 Move to Cart
          </button>
          <button class="btn-outline" style="padding: 10px 14px; border-radius: 50px;" onclick="removeFromWishlist(${item.id})" title="Remove from wishlist">
            ✕
          </button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

window.getWishlist = getWishlist;
window.saveWishlist = saveWishlist;
window.updateWishlistBadge = updateWishlistBadge;
window.isWishlisted = isWishlisted;
window.toggleWishlist = toggleWishlist;
window.removeFromWishlist = removeFromWishlist;
window.moveWishlistToCart = moveWishlistToCart;
window.renderWishlistPage = renderWishlistPage;
