/**
 * ============================================================
 * LUXE BOUTIQUE - THEME, TOAST, SCROLL & STORAGE HELPERS
 * ============================================================
 */

// --- 1. Dark / Light Mode Theme Manager ---
function initTheme() {
  const savedTheme = localStorage.getItem('luxe_theme') || 'dark';
  applyTheme(savedTheme);

  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  themeToggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(newTheme);
      showToast(`Switched to ${newTheme.toUpperCase()} luxury theme`, 'info');
    });
  });
}

function applyTheme(theme) {
  if (theme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
  localStorage.setItem('luxe_theme', theme);

  // Update button icons if present
  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  themeToggleBtns.forEach(btn => {
    const icon = btn.querySelector('.theme-icon');
    if (icon) {
      icon.innerHTML = theme === 'dark' ? '☀️' : '🌙';
    }
  });
}

// --- 2. Sticky Navbar Color & Height Change on Scroll ---
function initNavbarScroll() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
}

// --- 3. Scroll To Top Button ---
function initScrollTop() {
  let scrollBtn = document.querySelector('.scroll-top-btn');
  if (!scrollBtn) {
    scrollBtn = document.createElement('button');
    scrollBtn.className = 'scroll-top-btn';
    scrollBtn.innerHTML = '↑';
    scrollBtn.setAttribute('aria-label', 'Scroll to top');
    document.body.appendChild(scrollBtn);
  }

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      scrollBtn.classList.add('visible');
    } else {
      scrollBtn.classList.remove('visible');
    }
  });

  scrollBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// --- 4. Toast Notification System ---
function showToast(message, type = 'success') {
  let toastContainer = document.querySelector('.toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  toast.className = 'toast-item';

  let icon = '✨';
  if (type === 'error') icon = '⚠️';
  if (type === 'cart') icon = '🛍️';
  if (type === 'wishlist') icon = '💖';

  toast.innerHTML = `
    <span style="font-size: 1.25rem;">${icon}</span>
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('hide');
    setTimeout(() => {
      toast.remove();
    }, 350);
  }, 3500);
}

// --- 5. Loading Animation Overlay ---
function initLoadingSpinner() {
  const overlay = document.querySelector('.loading-overlay');
  if (overlay) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 500);
      }, 400);
    });
  }
}

// --- 6. Utility: Currency Formatter ---
function formatPrice(amount) {
  return '₹' + Number(amount).toFixed(2);
}

// --- 7. Recently Viewed Products (localStorage) ---
function addRecentlyViewed(productId) {
  let viewed = getRecentlyViewed();
  viewed = viewed.filter(id => id !== productId);
  viewed.unshift(productId);
  if (viewed.length > 6) {
    viewed = viewed.slice(0, 6);
  }
  localStorage.setItem('luxe_recently_viewed', JSON.stringify(viewed));
}

function getRecentlyViewed() {
  const data = localStorage.getItem('luxe_recently_viewed');
  return data ? JSON.parse(data) : [];
}

// Export functions to window
window.initTheme = initTheme;
window.initNavbarScroll = initNavbarScroll;
window.initScrollTop = initScrollTop;
window.showToast = showToast;
window.initLoadingSpinner = initLoadingSpinner;
window.formatPrice = formatPrice;
window.addRecentlyViewed = addRecentlyViewed;
window.getRecentlyViewed = getRecentlyViewed;
