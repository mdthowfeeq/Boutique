/**
 * ============================================================
 * LUXE BOUTIQUE - HERO IMAGE SLIDER (Vanilla JS)
 * ============================================================
 */

let currentSlideIndex = 0;
let slideInterval = null;
const SLIDE_DURATION = 5500; // 5.5 seconds per slide

function initSlider() {
  const slides = document.querySelectorAll('.slide');
  const prevBtn = document.querySelector('.slider-prev');
  const nextBtn = document.querySelector('.slider-next');
  const indicatorDots = document.querySelectorAll('.indicator-dot');

  if (!slides || slides.length === 0) return;

  function showSlide(index) {
    if (index >= slides.length) {
      currentSlideIndex = 0;
    } else if (index < 0) {
      currentSlideIndex = slides.length - 1;
    } else {
      currentSlideIndex = index;
    }

    slides.forEach((slide, i) => {
      slide.classList.remove('active');
      if (indicatorDots[i]) {
        indicatorDots[i].classList.remove('active');
      }
    });

    slides[currentSlideIndex].classList.add('active');
    if (indicatorDots[currentSlideIndex]) {
      indicatorDots[currentSlideIndex].classList.add('active');
    }
  }

  function nextSlide() {
    showSlide(currentSlideIndex + 1);
  }

  function prevSlide() {
    showSlide(currentSlideIndex - 1);
  }

  function startAutoPlay() {
    stopAutoPlay();
    slideInterval = setInterval(nextSlide, SLIDE_DURATION);
  }

  function stopAutoPlay() {
    if (slideInterval) clearInterval(slideInterval);
  }

  // Event listeners for arrows
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      prevSlide();
      startAutoPlay();
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      nextSlide();
      startAutoPlay();
    });
  }

  // Event listeners for indicator dots
  indicatorDots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      showSlide(index);
      startAutoPlay();
    });
  });

  // Pause on hover over slider
  const sliderContainer = document.querySelector('.slider-container');
  if (sliderContainer) {
    sliderContainer.addEventListener('mouseenter', stopAutoPlay);
    sliderContainer.addEventListener('mouseleave', startAutoPlay);

    // Touch swipe support for mobile
    let startX = 0;
    let endX = 0;
    sliderContainer.addEventListener('touchstart', (e) => {
      startX = e.changedTouches[0].screenX;
    }, { passive: true });

    sliderContainer.addEventListener('touchend', (e) => {
      endX = e.changedTouches[0].screenX;
      handleSwipe();
    }, { passive: true });

    function handleSwipe() {
      if (startX - endX > 50) {
        nextSlide();
        startAutoPlay();
      } else if (endX - startX > 50) {
        prevSlide();
        startAutoPlay();
      }
    }
  }

  // Show first slide and begin interval
  showSlide(0);
  startAutoPlay();
}

window.initSlider = initSlider;
