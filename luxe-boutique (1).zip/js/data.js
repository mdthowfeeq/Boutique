/**
 * ============================================================
 * LUXE BOUTIQUE - SAMPLE PRODUCT CATALOG (30+ Luxury Items)
 * ============================================================
 */

const boutiqueProducts = [
  {
    id: 1,
    name: "Aurora Silk Evening Gown",
    category: "Dresses",
    price: 389,
    oldPrice: 460,
    rating: 4.9,
    reviewsCount: 42,
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80",
    description: "Crafted from 100% pure mulberry charmeuse silk, this breathtaking floor-length evening gown drapes effortlessly. Features a delicate cowl neckline and adjustable criss-cross silk straps.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "Champagne", hex: "#f3e5ab" },
      { name: "Midnight Black", hex: "#1a1a1a" }
    ],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: 2,
    name: "Celeste Structured Leather Tote",
    category: "Handbags",
    price: 450,
    oldPrice: 520,
    rating: 5.0,
    reviewsCount: 68,
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Handcrafted in Florence from top-grain Saffiano leather, the Celeste Tote combines architecturally structured lines with 24K rose-gold plated hardware and a velvet-lined interior.",
    sizes: ["Standard"],
    colors: [
      { name: "Blush Pink", hex: "#f0c8c8" },
      { name: "Ivory White", hex: "#faf5ef" },
      { name: "Ebony Black", hex: "#1c1c1c" }
    ],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 3,
    name: "Gilded South Sea Pearl Earrings",
    category: "Jewelry",
    price: 240,
    oldPrice: 290,
    rating: 4.8,
    reviewsCount: 31,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80",
    description: "Luminous Baroque South Sea pearls suspended from 18-karat solid rose gold diamond-pavé hoops. A timeless luxury heirloom piece for special occasions.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "Yellow Gold", hex: "#d4af37" }
    ],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 4,
    name: "Versailles Cashmere Belted Coat",
    category: "Outerwear",
    price: 680,
    oldPrice: 790,
    rating: 4.9,
    reviewsCount: 55,
    image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80",
    description: "Double-faced virgin wool and Mongolian cashmere wrap coat with wide notched lapels and a self-tie sash belt. Extremely warm yet light as a feather.",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Camel Beige", hex: "#d4b28c" },
      { name: "Rose Blush", hex: "#deb8b8" },
      { name: "Charcoal", hex: "#3a3a3a" }
    ],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 5,
    name: "Athena Velvet Stiletto Pumps",
    category: "Footwear",
    price: 320,
    oldPrice: 380,
    rating: 4.7,
    reviewsCount: 29,
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80",
    description: "Italian silk velvet heels featuring an elegant 95mm stiletto heel, padded nappa leather insole, and a signature rose-gold gilded buckle accent.",
    sizes: ["36", "37", "38", "39", "40"],
    colors: [
      { name: "Rose Gold Velvet", hex: "#b76e79" },
      { name: "Emerald", hex: "#1e4d2b" },
      { name: "Midnight Black", hex: "#1a1a1a" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: 6,
    name: "Seraphina Organza Midi Dress",
    category: "Dresses",
    price: 340,
    oldPrice: 399,
    rating: 4.9,
    reviewsCount: 18,
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80",
    description: "Ethereal silk organza midi dress with hand-embroidered floral appliqué along the bodice and a sweeping romantic skirt.",
    sizes: ["S", "M", "L"],
    colors: [
      { name: "Soft Pink", hex: "#f7d6d6" },
      { name: "Ivory", hex: "#fffaf0" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 7,
    name: "Monaco Diamond Tennis Bracelet",
    category: "Jewelry",
    price: 590,
    oldPrice: 690,
    rating: 5.0,
    reviewsCount: 84,
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Flawless laboratory-grown diamonds set in 18-karat rose gold vermeil. Includes an authentic double-latch safety clasp for secure wear.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "White Gold", hex: "#e5e5e5" }
    ],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 8,
    name: "Florence Pleated Satin Dress",
    category: "Dresses",
    price: 275,
    oldPrice: 320,
    rating: 4.8,
    reviewsCount: 23,
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=800&q=80",
    description: "Sunburst pleated Japanese satin dress that shimmers with every step. Designed with a flattering elastic waist and removable metallic ribbon belt.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "Deep Bordeaux", hex: "#5c1d24" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 9,
    name: "Palazzo Quilted Lambskin Clutch",
    category: "Handbags",
    price: 360,
    oldPrice: 410,
    rating: 4.9,
    reviewsCount: 39,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80",
    description: "Ultra-supple quilted lambskin evening clutch featuring a detachable rose-gold chain strap and custom geometric turn-lock clasp.",
    sizes: ["Standard"],
    colors: [
      { name: "Blush Pink", hex: "#e8c5c8" },
      { name: "Champagne Gold", hex: "#d4af37" },
      { name: "Obsidian Black", hex: "#111111" }
    ],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 10,
    name: "Opulence Silk Scarf & Bowtie Set",
    category: "Accessories",
    price: 130,
    oldPrice: 160,
    rating: 4.8,
    reviewsCount: 47,
    image: "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=800&q=80",
    description: "Hand-rolled 90x90cm mulberry silk twill scarf printed with botanical art nouveau motifs in delicate rose gold, cream, and champagne.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose & Cream", hex: "#ebd6d6" },
      { name: "Gold & Navy", hex: "#d4af37" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 11,
    name: "Chantilly Lace Cocktail Dress",
    category: "Dresses",
    price: 310,
    oldPrice: 370,
    rating: 4.7,
    reviewsCount: 19,
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=800&q=80",
    description: "Intricate French Chantilly lace overlay with a sheer high neckline, sweetheart silk bodice, and scalloped hemline.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Nude", hex: "#d6a9a9" },
      { name: "Black Lace", hex: "#1a1a1a" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 12,
    name: "Lumière Crystal Pendant Necklace",
    category: "Jewelry",
    price: 190,
    oldPrice: 230,
    rating: 4.9,
    reviewsCount: 52,
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80",
    description: "Teardrop Austrian crystal pendant suspended from an 18-karat rose gold curb chain. Reflects a stunning prism of warm champagne light.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "Silver White", hex: "#e2e8f0" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: 13,
    name: "Empress Wool Trench Coat",
    category: "Outerwear",
    price: 540,
    oldPrice: 620,
    rating: 4.9,
    reviewsCount: 36,
    image: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=800&q=80",
    description: "Tailored luxury wool trench with storm flaps, tortoise buttons, and an interior monogrammed silk lining.",
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Warm Taupe", hex: "#b8a398" },
      { name: "Cream White", hex: "#f8f6f0" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 14,
    name: "Elysian Strappy Leather Sandals",
    category: "Footwear",
    price: 250,
    oldPrice: 295,
    rating: 4.8,
    reviewsCount: 22,
    image: "https://images.unsplash.com/photo-1562183241-b937e95585b6?auto=format&fit=crop&w=800&q=80",
    description: "Minimalist evening sandals featuring metallic rose-gold straps, a 75mm block heel for comfort, and cushioned leather footbeds.",
    sizes: ["36", "37", "38", "39", "40"],
    colors: [
      { name: "Rose Gold Metallic", hex: "#b76e79" },
      { name: "Gold Metallic", hex: "#d4af37" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 15,
    name: "Riviera Woven Straw Beach Bag",
    category: "Handbags",
    price: 220,
    oldPrice: 260,
    rating: 4.6,
    reviewsCount: 15,
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80",
    description: "Hand-woven raffia tote trimmed in Italian vegetable-tanned leather with a drawstring organic canvas interior pouch.",
    sizes: ["Standard"],
    colors: [
      { name: "Natural Straw", hex: "#e0cfb3" },
      { name: "Tan Leather", hex: "#a67b5b" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 16,
    name: "Brocade Floral Evening Dress",
    category: "Dresses",
    price: 420,
    oldPrice: 480,
    rating: 5.0,
    reviewsCount: 28,
    image: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80",
    description: "Metallic rose-gold floral brocade jacquard dress with a structured boned bodice and full pleated tea-length skirt.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Brocade", hex: "#b76e79" },
      { name: "Gold Brocade", hex: "#d4af37" }
    ],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 17,
    name: "Royal Diamond Cocktail Ring",
    category: "Jewelry",
    price: 480,
    oldPrice: 560,
    rating: 4.9,
    reviewsCount: 34,
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=800&q=80",
    description: "An extravagant 3.5-carat morganite center stone framed by a double halo of brilliant-cut diamonds in 18-karat rose gold.",
    sizes: ["5", "6", "7", "8"],
    colors: [
      { name: "Rose Gold Morganite", hex: "#f0c4c4" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 18,
    name: "Victoria Cashmere Poncho Wrap",
    category: "Outerwear",
    price: 360,
    oldPrice: 410,
    rating: 4.8,
    reviewsCount: 40,
    image: "https://images.unsplash.com/photo-1548624313-0396c75e4b1a?auto=format&fit=crop&w=800&q=80",
    description: "Ultra-cozy cashmere wrap poncho with genuine Fox-fur trimmed hood and rose-gold leather toggle closures.",
    sizes: ["One Size"],
    colors: [
      { name: "Oatmeal Beige", hex: "#e3dad1" },
      { name: "Blush Rose", hex: "#e8c5c8" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 19,
    name: "Sovereign Croc-Embossed Crossbody",
    category: "Handbags",
    price: 390,
    oldPrice: 450,
    rating: 4.9,
    reviewsCount: 51,
    image: "https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=800&q=80",
    description: "Luxurious crocodile-embossed Italian calfskin handbag featuring a fold-over flap, key clochette, and adjustable crossbody strap.",
    sizes: ["Standard"],
    colors: [
      { name: "Rose Cognac", hex: "#9e535c" },
      { name: "Midnight Black", hex: "#181818" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 20,
    name: "Satin Embellished Evening Mules",
    category: "Footwear",
    price: 290,
    oldPrice: 340,
    rating: 4.7,
    reviewsCount: 19,
    image: "https://images.unsplash.com/photo-1560343090-f0409e92791a?auto=format&fit=crop&w=800&q=80",
    description: "Pointed-toe silk satin mules adorned with crystal buckle embellishments and a wearable 70mm kitten heel.",
    sizes: ["36", "37", "38", "39", "40"],
    colors: [
      { name: "Soft Pink Satin", hex: "#f3dadc" },
      { name: "Black Satin", hex: "#1c1c1c" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 21,
    name: "Aphrodite Silk Slip Dress",
    category: "Dresses",
    price: 240,
    oldPrice: 280,
    rating: 4.8,
    reviewsCount: 62,
    image: "https://images.unsplash.com/photo-1502716119720-b23a93e5fc1b?auto=format&fit=crop&w=800&q=80",
    description: "Bias-cut 100% mulberry silk slip dress with a feminine V-neckline and side slit. Ideal for layering or effortless evening glamour.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" },
      { name: "Champagne", hex: "#eedcb3" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 22,
    name: "Celestial Pearl Cuff Bracelet",
    category: "Jewelry",
    price: 210,
    oldPrice: 250,
    rating: 4.9,
    reviewsCount: 27,
    image: "https://images.unsplash.com/photo-1611591472159-259f7ce81187?auto=format&fit=crop&w=800&q=80",
    description: "Sculptural 18-karat rose gold vermeil cuff set with twin freshwater Baroque pearls at open terminals.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 23,
    name: "Milan Tailored Wool Blazer",
    category: "Outerwear",
    price: 490,
    oldPrice: 560,
    rating: 4.9,
    reviewsCount: 44,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80",
    description: "Precision-tailored Italian virgin wool blazer with peaked lapels, structured shoulders, and engraved rose-gold crested buttons.",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Ivory Cream", hex: "#f8f5ef" },
      { name: "Midnight Navy", hex: "#1a2436" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 24,
    name: "Geneva Quilted Leather Backpack",
    category: "Handbags",
    price: 380,
    oldPrice: 430,
    rating: 4.7,
    reviewsCount: 21,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80",
    description: "Compact luxury quilted leather city backpack featuring rose-gold chains, dual zip compartments, and a plush microsuede interior.",
    sizes: ["Standard"],
    colors: [
      { name: "Rose Gold Blush", hex: "#d6a4ab" },
      { name: "Jet Black", hex: "#161616" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 25,
    name: "Aria Diamond Drop Necklace",
    category: "Jewelry",
    price: 360,
    oldPrice: 420,
    rating: 5.0,
    reviewsCount: 38,
    image: "https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?auto=format&fit=crop&w=800&q=80",
    description: "Delicate 18-karat rose gold Y-necklace featuring a cascading drop of laboratory diamonds that catch the light at every angle.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold", hex: "#b76e79" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: 26,
    name: "Camellia Silk Halter Gown",
    category: "Dresses",
    price: 410,
    oldPrice: 480,
    rating: 4.9,
    reviewsCount: 33,
    image: "https://images.unsplash.com/photo-1568252542512-9fe8fe9c87bb?auto=format&fit=crop&w=800&q=80",
    description: "Glamorous silk crepe halter gown with a softly gathered neckline, open cowl back, and subtle mermaid silhouette train.",
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Rose Blush", hex: "#cf9199" },
      { name: "Gold Champagne", hex: "#d4af37" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 27,
    name: "Siena Metallic Evening Clutch",
    category: "Handbags",
    price: 260,
    oldPrice: 310,
    rating: 4.8,
    reviewsCount: 25,
    image: "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=800&q=80",
    description: "Geometric metallic box clutch with a crystal-encrusted snap closure and drop-in rose gold shoulder chain.",
    sizes: ["Standard"],
    colors: [
      { name: "Rose Gold Metallic", hex: "#b76e79" },
      { name: "Silver", hex: "#c0c0c0" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 28,
    name: "Luxe Cashmere Lined Leather Gloves",
    category: "Accessories",
    price: 150,
    oldPrice: 180,
    rating: 4.9,
    reviewsCount: 58,
    image: "https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&w=800&q=80",
    description: "Hand-stitched Italian nappa leather gloves lined with 100% Mongolian cashmere. Includes touchscreen compatible fingertips.",
    sizes: ["6.5", "7", "7.5", "8"],
    colors: [
      { name: "Blush Rose", hex: "#d8acb1" },
      { name: "Cognac Brown", hex: "#7a432e" },
      { name: "Black", hex: "#141414" }
    ],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true
  },
  {
    id: 29,
    name: "Estelle Pearl Embellished Heels",
    category: "Footwear",
    price: 340,
    oldPrice: 395,
    rating: 4.8,
    reviewsCount: 26,
    image: "https://images.unsplash.com/photo-1515347619252-60a4bf4fff4f?auto=format&fit=crop&w=800&q=80",
    description: "Ankle-strap bridal and formal evening sandals featuring rows of lustrous freshwater pearls along the toe strap and heel.",
    sizes: ["36", "37", "38", "39", "40"],
    colors: [
      { name: "Ivory Pearl", hex: "#fcf8f2" },
      { name: "Rose Satin", hex: "#ebd3d6" }
    ],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false
  },
  {
    id: 30,
    name: "Duchess Rose Gold Sunglasses",
    category: "Accessories",
    price: 210,
    oldPrice: 250,
    rating: 4.9,
    reviewsCount: 41,
    image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80",
    description: "Oversized luxury cat-eye sunglasses with lightweight 18K rose-gold plated frames and gradient anti-reflective UV400 lenses.",
    sizes: ["One Size"],
    colors: [
      { name: "Rose Gold & Pink Lens", hex: "#b76e79" },
      { name: "Gold & Brown Lens", hex: "#d4af37" }
    ],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: true
  }
];

// Expose globally for vanilla scripts
window.boutiqueProducts = boutiqueProducts;
