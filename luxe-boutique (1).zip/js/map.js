/**
 * ============================================================
 * LUXE BOUTIQUE - INTERACTIVE STORE LOCATOR & MAP CONTROLLER
 * ============================================================
 */

export const BOUTIQUES = [
  {
    id: 'karur-flagship',
    name: 'Karur Flagship Atelier & Salon',
    city: 'Karur',
    country: 'India',
    region: 'India',
    address: '124 Kovai Road, Karur, Tamil Nadu 639002, India',
    lat: 10.9601,
    lng: 78.0766,
    phone: '+91 4324 220 100',
    hours: 'Mon–Sat: 10:00 AM – 8:30 PM | Sun: 11:00 AM – 7:00 PM',
    image: 'https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80',
    description: 'Our primary flagship salon housing the Master Tailoring Suite, Silk Weaving Archive, and Private Heirloom Jewelry Vault.',
    features: ['Private Bespoke Fitting', 'Bridal VIP Salon', 'Heirloom Jewelry Vault', 'Complimentary Hospitality']
  },
  {
    id: 'chennai-salon',
    name: 'Chennai Taj Salon & VIP Suite',
    city: 'Chennai',
    country: 'India',
    region: 'India',
    address: 'Express Avenue Mall, Club House Rd, Mount Road, Chennai, Tamil Nadu 600002, India',
    lat: 13.0604,
    lng: 80.2496,
    phone: '+91 44 2846 1100',
    hours: 'Mon–Sat: 10:00 AM – 8:00 PM | Sun: 11:00 AM – 7:00 PM',
    image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80',
    description: 'Exclusive luxury salon featuring bespoke silk sarees, evening gowns, and personal styling consultation.',
    features: ['Personal Styling Suite', 'Couture Silk Lounge', 'VIP Bridal Suite']
  },
  {
    id: 'mumbai-salon',
    name: 'Mumbai Taj Mahal Palace Atelier',
    city: 'Mumbai',
    country: 'India',
    region: 'India',
    address: 'Apollo Bunder, Colaba, Mumbai, Maharashtra 400001, India',
    lat: 18.9220,
    lng: 72.8332,
    phone: '+91 22 6665 3300',
    hours: 'Mon–Sat: 10:30 AM – 8:00 PM',
    image: 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=800&q=80',
    description: 'Overlooking the Arabian Sea, featuring handcrafted leather goods and custom rose-gold metalwork.',
    features: ['Custom Gold Monogramming', 'Artisan Workshop', 'Private Trunk Shows']
  },
  {
    id: 'bengaluru-salon',
    name: 'Bengaluru UB City Luxury Suite',
    city: 'Bengaluru',
    country: 'India',
    region: 'India',
    address: 'UB City Collection, Vittal Mallya Rd, Bengaluru, Karnataka 560001, India',
    lat: 12.9716,
    lng: 77.5946,
    phone: '+91 80 4111 2200',
    hours: 'Mon–Sat: 10:00 AM – 8:00 PM',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
    description: 'Contemporary high-fashion salon providing private wardrobe styling and fine jewelry curation.',
    features: ['VIP Appointment Suite', 'Private Wardrobe Styling', 'Fine Jewelry Vault']
  },
  {
    id: 'dubai-salon',
    name: 'Dubai Mall Fashion Avenue Salon',
    city: 'Dubai',
    country: 'UAE',
    region: 'Middle East',
    address: 'Fashion Avenue, The Dubai Mall, Downtown Dubai, UAE',
    lat: 25.1972,
    lng: 55.2744,
    phone: '+971 4 362 7500',
    hours: 'Mon–Sun: 10:00 AM – 10:00 PM',
    image: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80',
    description: 'Premier international fashion suite showcasing signature haute couture collections and footwear.',
    features: ['International Runway Suite', 'Personal Concierge', 'Gold Vault']
  }
];

let gMapInstance = null;
let leafletMapInstance = null;
let activeMarkers = [];
let selectedBoutique = BOUTIQUES[0];

/**
 * Initialize Store Locator Map
 */
export function initStoreLocatorMap() {
  const container = document.getElementById('store-locator-container');
  if (!container) return;

  renderStoreLocatorHTML(container);
  setupStoreLocatorEvents();
  
  // Try loading Google Maps API first, fallback to Leaflet OSM if key absent
  const apiKey = (process.env && process.env.GOOGLE_MAPS_PLATFORM_KEY) || window.GOOGLE_MAPS_PLATFORM_KEY || '';

  if (apiKey && apiKey !== 'YOUR_API_KEY') {
    loadGoogleMapsAPI(apiKey)
      .then(() => {
        initGoogleMap();
      })
      .catch((err) => {
        console.warn('Google Maps API failed to load, initializing Leaflet fallback:', err);
        initLeafletMap();
      });
  } else {
    // Render Leaflet fallback map directly + show helpful API Key Banner
    initLeafletMap();
  }
}

/**
 * Render the Store Locator Component Layout
 */
function renderStoreLocatorHTML(container) {
  const apiKey = (process.env && process.env.GOOGLE_MAPS_PLATFORM_KEY) || window.GOOGLE_MAPS_PLATFORM_KEY || '';
  const hasKey = apiKey && apiKey !== 'YOUR_API_KEY';

  container.innerHTML = `
    <div class="store-locator-wrapper">
      ${!hasKey ? `
        <div class="api-key-notice-banner">
          <div class="notice-icon">📍</div>
          <div class="notice-text">
            <strong>Google Maps Platform Integration Ready:</strong> Displaying interactive boutique map.
            <span class="notice-sub">To enable custom Google Maps tiles & Places API: Add <code>GOOGLE_MAPS_PLATFORM_KEY</code> in <strong>Settings ⚙️ → Secrets</strong>.</span>
          </div>
        </div>
      ` : ''}

      <div class="store-locator-grid">
        <!-- Sidebar Controls & List -->
        <div class="store-sidebar">
          <div class="store-search-box">
            <span class="search-icon">🔍</span>
            <input type="text" id="boutique-search-input" placeholder="Search city, region, or address..." aria-label="Search boutiques" />
          </div>

          <div class="store-region-pills">
            <button class="region-pill active" data-region="All">All Salons (${BOUTIQUES.length})</button>
            <button class="region-pill" data-region="India">India (4)</button>
            <button class="region-pill" data-region="Middle East">Middle East (1)</button>
          </div>

          <div class="boutique-cards-list" id="boutique-cards-list">
            <!-- Dynamically populated -->
          </div>
        </div>

        <!-- Map & Selected Boutique Detail -->
        <div class="store-map-column">
          <div id="store-map-canvas" class="store-map-canvas"></div>
          
          <div class="selected-boutique-card" id="selected-boutique-card">
            <!-- Dynamically updated -->
          </div>
        </div>
      </div>
    </div>
  `;

  renderBoutiqueCards(BOUTIQUES);
  renderSelectedBoutiqueDetail(selectedBoutique);
}

/**
 * Render list of boutique cards in sidebar
 */
function renderBoutiqueCards(boutiquesList) {
  const listEl = document.getElementById('boutique-cards-list');
  if (!listEl) return;

  if (boutiquesList.length === 0) {
    listEl.innerHTML = `<div class="no-boutiques-msg">No Luxe Boutique salons found matching your search.</div>`;
    return;
  }

  listEl.innerHTML = boutiquesList.map((b) => `
    <div class="boutique-item-card ${b.id === selectedBoutique.id ? 'active' : ''}" data-id="${b.id}">
      <div class="boutique-item-header">
        <h4 class="boutique-item-title">${b.name}</h4>
        <span class="boutique-region-tag">${b.city}, ${b.country}</span>
      </div>
      <p class="boutique-item-address">${b.address}</p>
      <div class="boutique-item-footer">
        <span class="boutique-phone">📞 ${b.phone}</span>
        <button class="boutique-select-btn" onclick="window.selectBoutiqueById('${b.id}')">View Salon →</button>
      </div>
    </div>
  `).join('');
}

/**
 * Render detail view for selected boutique below map
 */
function renderSelectedBoutiqueDetail(b) {
  const detailEl = document.getElementById('selected-boutique-card');
  if (!detailEl || !b) return;

  const encodedAddress = encodeURIComponent(`${b.name}, ${b.address}`);
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`;

  detailEl.innerHTML = `
    <div class="selected-detail-inner">
      <div class="selected-detail-img-wrap">
        <img src="${b.image}" alt="${b.name}" loading="lazy" />
        <span class="selected-badge">Flagship Salon</span>
      </div>
      <div class="selected-detail-content">
        <div class="selected-header">
          <h3>${b.name}</h3>
          <span class="selected-location-sub">📍 ${b.city}, ${b.country}</span>
        </div>
        <p class="selected-desc">${b.description}</p>
        
        <div class="selected-info-grid">
          <div>
            <strong>📍 Address:</strong>
            <p>${b.address}</p>
          </div>
          <div>
            <strong>⏰ Salon Hours:</strong>
            <p>${b.hours}</p>
          </div>
          <div>
            <strong>📞 Direct Ambassador:</strong>
            <p><a href="tel:${b.phone.replace(/\s+/g, '')}" class="phone-link">${b.phone}</a></p>
          </div>
        </div>

        <div class="selected-features-tags">
          ${b.features.map(f => `<span class="feature-tag">✦ ${f}</span>`).join('')}
        </div>

        <div class="selected-actions">
          <a href="${directionsUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
            🗺️ Get Directions in Google Maps
          </a>
          <button class="btn btn-secondary" onclick="window.showToast('Appointment request sent to ${b.city} Salon Ambassador!', 'success')">
            📅 Book Private VIP Appointment
          </button>
        </div>
      </div>
    </div>
  `;
}

/**
 * Setup event listeners for search and filters
 */
function setupStoreLocatorEvents() {
  const searchInput = document.getElementById('boutique-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      filterBoutiques();
    });
  }

  const regionPills = document.querySelectorAll('.store-region-pills .region-pill');
  regionPills.forEach(pill => {
    pill.addEventListener('click', () => {
      regionPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      filterBoutiques();
    });
  });

  window.selectBoutiqueById = (id) => {
    const found = BOUTIQUES.find(b => b.id === id);
    if (!found) return;

    selectedBoutique = found;
    renderSelectedBoutiqueDetail(found);

    // Update active highlight on cards
    document.querySelectorAll('.boutique-item-card').forEach(card => {
      card.classList.toggle('active', card.getAttribute('data-id') === id);
    });

    // Pan map to location
    if (gMapInstance) {
      gMapInstance.panTo({ lat: found.lat, lng: found.lng });
      gMapInstance.setZoom(14);
    } else if (leafletMapInstance) {
      leafletMapInstance.setView([found.lat, found.lng], 14, { animate: true });
    }
  };
}

function filterBoutiques() {
  const searchInput = document.getElementById('boutique-search-input');
  const activePill = document.querySelector('.store-region-pills .region-pill.active');
  
  const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selectedRegion = activePill ? activePill.getAttribute('data-region') : 'All';

  const filtered = BOUTIQUES.filter(b => {
    const matchesRegion = selectedRegion === 'All' || b.region === selectedRegion;
    const matchesQuery = !query || 
      b.name.toLowerCase().includes(query) ||
      b.city.toLowerCase().includes(query) ||
      b.country.toLowerCase().includes(query) ||
      b.address.toLowerCase().includes(query);
    return matchesRegion && matchesQuery;
  });

  renderBoutiqueCards(filtered);

  if (filtered.length > 0 && !filtered.includes(selectedBoutique)) {
    window.selectBoutiqueById(filtered[0].id);
  }
}

/**
 * Load Google Maps JS SDK dynamically
 */
function loadGoogleMapsAPI(apiKey) {
  return new Promise((resolve, reject) => {
    if (window.google && window.google.maps) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,marker&v=weekly`;
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = (err) => reject(err);
    document.head.appendChild(script);
  });
}

/**
 * Initialize Google Map Instance
 */
function initGoogleMap() {
  const canvas = document.getElementById('store-map-canvas');
  if (!canvas) return;

  const center = { lat: selectedBoutique.lat, lng: selectedBoutique.lng };

  const luxuryMapStyle = [
    { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.fill", stylers: [{ color: "#d4af37" }] },
    {
      featureType: "administrative.locality",
      elementType: "labels.text.fill",
      stylers: [{ color: "#f2d184" }]
    },
    {
      featureType: "poi",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d5a253" }]
    },
    {
      featureType: "poi.park",
      elementType: "geometry",
      stylers: [{ color: "#263c3f" }]
    },
    {
      featureType: "road",
      elementType: "geometry",
      stylers: [{ color: "#38414e" }]
    },
    {
      featureType: "road",
      elementType: "geometry.stroke",
      stylers: [{ color: "#212a37" }]
    },
    {
      featureType: "road",
      elementType: "labels.text.fill",
      stylers: [{ color: "#9ca5b3" }]
    },
    {
      featureType: "water",
      elementType: "geometry",
      stylers: [{ color: "#17263c" }]
    }
  ];

  gMapInstance = new google.maps.Map(canvas, {
    center: center,
    zoom: 12,
    styles: luxuryMapStyle,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: true,
    internalUsageAttributionIds: ['gmp_mcp_codeassist_v1_aistudio']
  });

  const infoWindow = new google.maps.InfoWindow();

  BOUTIQUES.forEach((b) => {
    const marker = new google.maps.Marker({
      position: { lat: b.lat, lng: b.lng },
      map: gMapInstance,
      title: b.name,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: '#bfa15f',
        fillOpacity: 1,
        strokeWeight: 3,
        strokeColor: '#ffffff'
      }
    });

    marker.addListener('click', () => {
      window.selectBoutiqueById(b.id);
      infoWindow.setContent(`
        <div style="padding: 10px; max-width: 220px; font-family: sans-serif; color: #1a1a1a;">
          <h4 style="margin: 0 0 6px 0; font-size: 0.95rem; font-weight: 700; color: #1a1a1a;">${b.name}</h4>
          <p style="margin: 0 0 8px 0; font-size: 0.8rem; color: #666;">${b.address}</p>
          <a href="#" onclick="window.selectBoutiqueById('${b.id}'); return false;" style="font-size: 0.8rem; font-weight: 600; color: #bfa15f; text-decoration: none;">Explore Salon Details →</a>
        </div>
      `);
      infoWindow.open(gMapInstance, marker);
    });

    activeMarkers.push(marker);
  });
}

/**
 * Fallback: Initialize Leaflet Map with OpenStreetMap
 */
function initLeafletMap() {
  const canvas = document.getElementById('store-map-canvas');
  if (!canvas) return;

  // Load Leaflet CSS & JS dynamically if not loaded
  loadLeafletResources().then(() => {
    if (leafletMapInstance) {
      leafletMapInstance.remove();
    }

    leafletMapInstance = L.map(canvas).setView([selectedBoutique.lat, selectedBoutique.lng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors | Luxe Boutique'
    }).addTo(leafletMapInstance);

    // Custom Gold Pin Icon
    const goldIcon = L.divIcon({
      className: 'custom-leaflet-gold-pin',
      html: `<div style="background: var(--color-rose-gold); width: 20px; height: 20px; border-radius: 50%; border: 3px solid #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.3);"></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    BOUTIQUES.forEach(b => {
      const marker = L.marker([b.lat, b.lng], { icon: goldIcon }).addTo(leafletMapInstance);
      marker.bindPopup(`
        <div style="font-family: inherit; font-size: 0.85rem; padding: 4px;">
          <strong style="color: var(--color-text); font-size: 0.95rem;">${b.name}</strong><br>
          <span style="color: var(--color-text-muted);">${b.city}, ${b.country}</span><br>
          <button onclick="window.selectBoutiqueById('${b.id}')" style="margin-top: 8px; background: var(--color-rose-gold); color: #fff; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 0.78rem;">View Salon</button>
        </div>
      `);

      marker.on('click', () => {
        window.selectBoutiqueById(b.id);
      });
    });
  }).catch(err => {
    console.error('Leaflet failed to load:', err);
  });
}

function loadLeafletResources() {
  return new Promise((resolve) => {
    if (window.L) {
      resolve();
      return;
    }

    const cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(cssLink);

    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.onload = () => resolve();
    document.head.appendChild(script);
  });
}

window.initStoreLocatorMap = initStoreLocatorMap;
