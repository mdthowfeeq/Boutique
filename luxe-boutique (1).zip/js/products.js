/**
 * ============================================================
 * LUXE BOUTIQUE - PRODUCTS CATALOG, FILTERS, SHOP & DETAILS
 * ============================================================
 */

let currentShopCategory = 'All';
let currentSearchQuery = '';
let currentSortOrder = 'default';
let maxPriceFilter = 1000;
let shopVisibleCount = 9;
const SHOP_PAGE_STEP = 9;

// --- 1. Product Card Builder (Reusable HTML generator) ---
function createProductCardHTML(product) {
  const isHeartActive = window.isWishlisted && window.isWishlisted(product.id);
  const heartIcon = isHeartActive ? '💖' : '♡';
  const heartClass = isHeartActive ? 'active-heart' : '';

  let discountBadge = '';
  if (product.oldPrice && product.oldPrice > product.price) {
    const pct = Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100);
    discountBadge = `<span class="badge-discount">-${pct}%</span>`;
  }

  let tagBadge = '';
  if (product.isBestSeller) {
    tagBadge = `<span class="badge-tag">Best Seller</span>`;
  } else if (product.isNewArrival) {
    tagBadge = `<span class="badge-tag" style="background: var(--color-black);">New</span>`;
  }

  return `
    <div class="product-card card-hover animate-fade-in" data-category="${product.category}">
      <div class="product-img-wrap">
        ${discountBadge}
        ${tagBadge}
        <a href="product.html?id=${product.id}">
          <img src="${product.image}" alt="${product.name}" loading="lazy" />
        </a>
        <div class="product-actions">
          <button class="card-action-icon wishlist-btn-${product.id} ${heartClass}"
            data-id="${product.id}"
            onclick="toggleWishlist(${product.id})"
            title="Add to Wishlist"
            aria-label="Wishlist button">
            ${heartIcon}
          </button>
          <button class="card-action-icon"
            onclick="openQuickViewModal(${product.id})"
            title="Quick View"
            aria-label="Quick View button">
            👁️
          </button>
        </div>
      </div>
      <div class="product-info">
        <span class="product-cat">${product.category}</span>
        <h3 class="product-name">
          <a href="product.html?id=${product.id}">${product.name}</a>
        </h3>
        <div class="product-rating">
          <span>★</span>
          <span>★</span>
          <span>★</span>
          <span>★</span>
          <span>★</span>
          <span class="rating-number">(${product.rating} / ${product.reviewsCount || 20})</span>
        </div>
        <div class="product-price-wrap">
          <span class="current-price">₹${Number(product.price).toFixed(2)}</span>
          ${product.oldPrice ? `<span class="old-price">₹${Number(product.oldPrice).toFixed(2)}</span>` : ''}
        </div>
        <button class="btn-add-cart btn-ripple" onclick="addToCart(${product.id}, 1)">
          🛒 Add to Cart
        </button>
      </div>
    </div>
  `;
}

// --- 2. Home Page: New Arrivals & Best Sellers ---
function initHomeProductSections() {
  const products = window.boutiqueProducts || [];

  const newArrivalsContainer = document.getElementById('new-arrivals-container');
  if (newArrivalsContainer) {
    const newItems = products.filter(p => p.isNewArrival).slice(0, 4);
    newArrivalsContainer.innerHTML = newItems.map(p => createProductCardHTML(p)).join('');
  }

  const bestSellersContainer = document.getElementById('best-sellers-container');
  if (bestSellersContainer) {
    const bestItems = products.filter(p => p.isBestSeller).slice(0, 4);
    bestSellersContainer.innerHTML = bestItems.map(p => createProductCardHTML(p)).join('');
  }
}

// --- 3. Shop Page logic (Search, Filters, Sorting, Load More) ---
function initShopPage() {
  const shopGrid = document.getElementById('shop-products-grid');
  if (!shopGrid) return; // Not on shop page

  const products = window.boutiqueProducts || [];
  shopVisibleCount = SHOP_PAGE_STEP;

  // Category Pills
  const catPills = document.querySelectorAll('.cat-pill');
  catPills.forEach(pill => {
    pill.addEventListener('click', () => {
      catPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentShopCategory = pill.getAttribute('data-cat') || 'All';
      shopVisibleCount = SHOP_PAGE_STEP;
      renderShopProducts();
    });
  });

  // Search input
  const searchInput = document.getElementById('shop-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearchQuery = e.target.value.trim().toLowerCase();
      shopVisibleCount = SHOP_PAGE_STEP;
      renderShopProducts();
    });
  }

  // Sort dropdown
  const sortSelect = document.getElementById('shop-sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentSortOrder = e.target.value;
      shopVisibleCount = SHOP_PAGE_STEP;
      renderShopProducts();
    });
  }

  // Price range slider
  const priceSlider = document.getElementById('shop-price-slider');
  const priceLabel = document.getElementById('shop-price-value');
  if (priceSlider && priceLabel) {
    priceSlider.addEventListener('input', (e) => {
      maxPriceFilter = Number(e.target.value);
      priceLabel.textContent = `₹${maxPriceFilter}`;
      shopVisibleCount = SHOP_PAGE_STEP;
      renderShopProducts();
    });
  }

  // Load more button
  const loadMoreBtn = document.getElementById('load-more-btn');
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', () => {
      shopVisibleCount += SHOP_PAGE_STEP;
      renderShopProducts();
    });
  }

  renderShopProducts();
}

function renderShopProducts() {
  const shopGrid = document.getElementById('shop-products-grid');
  const emptyStateEl = document.getElementById('shop-empty-state');
  const loadMoreBtn = document.getElementById('load-more-btn');
  const resultCountEl = document.getElementById('shop-result-count');

  if (!shopGrid) return;

  const products = window.boutiqueProducts || [];

  // 1. Filter by category
  let filtered = products.filter(p => {
    if (currentShopCategory !== 'All' && p.category !== currentShopCategory) {
      return false;
    }
    // 2. Filter by search query
    if (currentSearchQuery) {
      const matchName = p.name.toLowerCase().includes(currentSearchQuery);
      const matchCat = p.category.toLowerCase().includes(currentSearchQuery);
      const matchDesc = p.description.toLowerCase().includes(currentSearchQuery);
      if (!matchName && !matchCat && !matchDesc) return false;
    }
    // 3. Filter by price
    if (p.price > maxPriceFilter) {
      return false;
    }
    return true;
  });

  // 4. Sort
  if (currentSortOrder === 'price-asc') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (currentSortOrder === 'price-desc') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (currentSortOrder === 'newest') {
    filtered.sort((a, b) => (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0));
  }

  // Display summary count
  if (resultCountEl) {
    resultCountEl.textContent = `Showing ${Math.min(shopVisibleCount, filtered.length)} of ${filtered.length} luxury items`;
  }

  // Render items up to shopVisibleCount
  const toShow = filtered.slice(0, shopVisibleCount);

  if (toShow.length === 0) {
    shopGrid.style.display = 'none';
    if (emptyStateEl) emptyStateEl.style.display = 'block';
    if (loadMoreBtn) loadMoreBtn.style.display = 'none';
    return;
  }

  shopGrid.style.display = 'grid';
  if (emptyStateEl) emptyStateEl.style.display = 'none';

  shopGrid.innerHTML = toShow.map(p => createProductCardHTML(p)).join('');

  if (loadMoreBtn) {
    loadMoreBtn.style.display = (shopVisibleCount < filtered.length) ? 'inline-flex' : 'none';
  }
}

// --- 4. Quick View Modal ---
function openQuickViewModal(productId) {
  const products = window.boutiqueProducts || [];
  const product = products.find(p => p.id === Number(productId));
  if (!product) return;

  const overlay = document.getElementById('quick-view-overlay');
  const contentBox = document.getElementById('quick-view-content');
  if (!overlay || !contentBox) return;

  const sizesHTML = (product.sizes || ['Standard']).map((sz, idx) => `
    <button class="size-btn ${idx === 0 ? 'active' : ''}" onclick="selectModalSize(this)">
      ${sz}
    </button>
  `).join('');

  const colorsHTML = (product.colors || [{name: 'Default', hex: '#b76e79'}]).map((col, idx) => `
    <div class="color-circle ${idx === 0 ? 'active' : ''}"
         style="background-color: ${col.hex};"
         title="${col.name}"
         onclick="selectModalColor(this, '${col.name}')">
    </div>
  `).join('');

  contentBox.innerHTML = `
    <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 36px; align-items: start;">
      <div class="main-image-wrap">
        <img src="${product.image}" alt="${product.name}" />
      </div>
      <div>
        <span class="details-cat">${product.category}</span>
        <h3 style="font-family: var(--font-serif); font-size: 1.85rem; margin: 8px 0 12px 0;">${product.name}</h3>
        <div class="product-rating" style="margin-bottom: 12px;">
          ★ ★ ★ ★ ★ <span class="rating-number" style="color: var(--color-text-muted);">(${product.rating})</span>
        </div>
        <div class="details-price-row">
          <span class="details-current-price">₹${Number(product.price).toFixed(2)}</span>
          ${product.oldPrice ? `<span class="details-old-price">₹${Number(product.oldPrice).toFixed(2)}</span>` : ''}
        </div>
        <p style="color: var(--color-text-muted); font-size: 0.98rem; margin-bottom: 22px;">${product.description}</p>
        <div class="option-group">
          <span class="option-label">Select Size</span>
          <div class="sizes-list" id="modal-sizes-list">${sizesHTML}</div>
        </div>
        <div class="option-group">
          <span class="option-label">Select Color</span>
          <div class="colors-list" id="modal-colors-list">${colorsHTML}</div>
        </div>
        <div style="display: flex; gap: 14px; margin-top: 28px;">
          <button class="btn btn-primary" onclick="addModalItemToCart(${product.id})">
            🛒 Add to Cart
          </button>
          <a href="product.html?id=${product.id}" class="btn btn-outline">
            Full Details
          </a>
        </div>
      </div>
    </div>
  `;

  overlay.classList.add('active');
}

function closeQuickViewModal() {
  const overlay = document.getElementById('quick-view-overlay');
  if (overlay) overlay.classList.remove('active');
}

function selectModalSize(btn) {
  const all = document.querySelectorAll('#modal-sizes-list .size-btn');
  all.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function selectModalColor(el, name) {
  const all = document.querySelectorAll('#modal-colors-list .color-circle');
  all.forEach(c => c.classList.remove('active'));
  el.classList.add('active');
}

function addModalItemToCart(productId) {
  let size = 'Standard';
  const activeSize = document.querySelector('#modal-sizes-list .size-btn.active');
  if (activeSize) size = activeSize.textContent.trim();

  let color = 'Default';
  const activeColor = document.querySelector('#modal-colors-list .color-circle.active');
  if (activeColor) color = activeColor.getAttribute('title') || 'Default';

  if (window.addToCart) {
    addToCart(productId, 1, size, color);
    closeQuickViewModal();
  }
}

// --- 5. Product Details Page Logic ---
function initProductDetailsPage() {
  const detailsContainer = document.getElementById('product-details-container');
  if (!detailsContainer) return; // Not on product page

  const params = new URLSearchParams(window.location.search);
  const idParam = params.get('id') || '1';

  const products = window.boutiqueProducts || [];
  const product = products.find(p => p.id === Number(idParam)) || products[0];

  if (!product) return;

  // Track in recently viewed
  if (window.addRecentlyViewed) {
    addRecentlyViewed(product.id);
  }

  // Build thumbnails array
  const thumbImages = [
    product.image,
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80"
  ];

  const sizesHTML = (product.sizes || ['Standard']).map((sz, idx) => `
    <button class="size-btn ${idx === 0 ? 'active' : ''}" onclick="selectPageSize(this)">
      ${sz}
    </button>
  `).join('');

  const colorsHTML = (product.colors || [{name: 'Default', hex: '#b76e79'}]).map((col, idx) => `
    <div class="color-circle ${idx === 0 ? 'active' : ''}"
         style="background-color: ${col.hex};"
         title="${col.name}"
         onclick="selectPageColor(this, '${col.name}')">
    </div>
  `).join('');

  detailsContainer.innerHTML = `
    <div class="product-details-grid">
      <div class="gallery-container">
        <div class="main-image-wrap img-zoom-container" id="details-zoom-wrap">
          <img src="${product.image}" id="details-main-img" alt="${product.name}" />
        </div>
        <div class="thumbnails-row">
          ${thumbImages.map((src, i) => `
            <div class="thumb-item ${i === 0 ? 'active' : ''}" onclick="changeMainImage(this, '${src}')">
              <img src="${src}" alt="Thumbnail ${i + 1}" />
            </div>
          `).join('')}
        </div>
      </div>

      <div class="details-content">
        <span class="details-cat">${product.category}</span>
        <h1 class="details-title">${product.name}</h1>
        <div class="product-rating" style="margin-bottom: 16px; font-size: 1rem;">
          ★ ★ ★ ★ ★ <span class="rating-number">(${product.rating} / ${product.reviewsCount || 40} Customer Reviews)</span>
        </div>
        <div class="details-price-row">
          <span class="details-current-price">₹${Number(product.price).toFixed(2)}</span>
          ${product.oldPrice ? `<span class="details-old-price">₹${Number(product.oldPrice).toFixed(2)}</span>` : ''}
        </div>
        <p class="details-desc">${product.description}</p>

        <div class="option-group">
          <span class="option-label">Available Sizes</span>
          <div class="sizes-list" id="page-sizes-list">${sizesHTML}</div>
        </div>

        <div class="option-group">
          <span class="option-label">Available Colors</span>
          <div class="colors-list" id="page-colors-list">${colorsHTML}</div>
        </div>

        <div class="purchase-row">
          <div class="qty-selector">
            <button class="qty-btn" onclick="adjustPageQty(-1)">−</button>
            <span class="qty-value" id="page-qty-val">1</span>
            <button class="qty-btn" onclick="adjustPageQty(1)">+</button>
          </div>
          <button class="btn btn-primary" onclick="addPageItemToCart(${product.id})">
            🛒 Add to Cart
          </button>
          <button class="btn btn-outline" onclick="toggleWishlist(${product.id})" style="padding: 14px 22px;">
            💖 Wishlist
          </button>
        </div>

        <div style="margin-top: 32px; padding-top: 24px; border-top: 1px solid var(--color-border); color: var(--color-text-muted); font-size: 0.9rem;">
          <p>✓ <strong>Complimentary Luxury Packaging:</strong> Wrapped in signature rose-gold ribbon.</p>
          <p>✓ <strong>Authenticity Guaranteed:</strong> Hand-crafted by master artisans.</p>
          <p>✓ <strong>Free Worldwide Shipping:</strong> On orders above ₹2000.</p>
        </div>
      </div>
    </div>
  `;

  // Init Related Products
  renderRelatedProducts(product);

  // Init Recently Viewed Products
  renderRecentlyViewedProducts();
}

function changeMainImage(thumbEl, newSrc) {
  const mainImg = document.getElementById('details-main-img');
  const allThumbs = document.querySelectorAll('.thumb-item');
  if (mainImg) {
    mainImg.src = newSrc;
  }
  allThumbs.forEach(el => el.classList.remove('active'));
  thumbEl.classList.add('active');
}

function selectPageSize(btn) {
  const all = document.querySelectorAll('#page-sizes-list .size-btn');
  all.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function selectPageColor(el, name) {
  const all = document.querySelectorAll('#page-colors-list .color-circle');
  all.forEach(c => c.classList.remove('active'));
  el.classList.add('active');
}

let currentPageQty = 1;
function adjustPageQty(change) {
  const qtyValEl = document.getElementById('page-qty-val');
  if (!qtyValEl) return;
  currentPageQty += change;
  if (currentPageQty < 1) currentPageQty = 1;
  qtyValEl.textContent = currentPageQty;
}

function addPageItemToCart(productId) {
  let size = 'Standard';
  const activeSize = document.querySelector('#page-sizes-list .size-btn.active');
  if (activeSize) size = activeSize.textContent.trim();

  let color = 'Default';
  const activeColor = document.querySelector('#page-colors-list .color-circle.active');
  if (activeColor) color = activeColor.getAttribute('title') || 'Default';

  if (window.addToCart) {
    addToCart(productId, currentPageQty, size, color);
  }
}

function renderRelatedProducts(product) {
  const relatedContainer = document.getElementById('related-products-container');
  if (!relatedContainer) return;

  const products = window.boutiqueProducts || [];
  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  if (related.length === 0) {
    relatedContainer.innerHTML = products.slice(0, 4).map(p => createProductCardHTML(p)).join('');
  } else {
    relatedContainer.innerHTML = related.map(p => createProductCardHTML(p)).join('');
  }
}

function renderRecentlyViewedProducts() {
  const recentContainer = document.getElementById('recently-viewed-container');
  if (!recentContainer || !window.getRecentlyViewed) return;

  const viewedIds = getRecentlyViewed();
  const products = window.boutiqueProducts || [];
  const recentItems = viewedIds
    .map(id => products.find(p => p.id === Number(id)))
    .filter(Boolean)
    .slice(0, 4);

  if (recentItems.length === 0) {
    const sectionWrap = document.getElementById('recently-viewed-section');
    if (sectionWrap) sectionWrap.style.display = 'none';
    return;
  }

  recentContainer.innerHTML = recentItems.map(p => createProductCardHTML(p)).join('');
}

window.createProductCardHTML = createProductCardHTML;
window.initHomeProductSections = initHomeProductSections;
window.initShopPage = initShopPage;
window.renderShopProducts = renderShopProducts;
window.openQuickViewModal = openQuickViewModal;
window.closeQuickViewModal = closeQuickViewModal;
window.selectModalSize = selectModalSize;
window.selectModalColor = selectModalColor;
window.addModalItemToCart = addModalItemToCart;
window.initProductDetailsPage = initProductDetailsPage;
window.changeMainImage = changeMainImage;
window.selectPageSize = selectPageSize;
window.selectPageColor = selectPageColor;
window.adjustPageQty = adjustPageQty;
window.addPageItemToCart = addPageItemToCart;
