/**
 * ============================================================
 * LUXE BOUTIQUE - MAIN APPLICATION CONTROLLER (app.js)
 * ============================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Core Global Modules
  if (window.initTheme) window.initTheme();
  if (window.initNavbarScroll) window.initNavbarScroll();
  if (window.initScrollTop) window.initScrollTop();
  if (window.initLoadingSpinner) window.initLoadingSpinner();

  // 2. Badges
  if (window.updateCartBadge) window.updateCartBadge();
  if (window.updateWishlistBadge) window.updateWishlistBadge();

  // 3. Page-specific controllers
  if (window.initSlider) window.initSlider();
  if (window.initHomeProductSections) window.initHomeProductSections();
  if (window.initShopPage) window.initShopPage();
  if (window.initProductDetailsPage) window.initProductDetailsPage();
  if (window.renderCartPage) window.renderCartPage();
  if (window.renderWishlistPage) window.renderWishlistPage();
  if (window.initStoreLocatorMap) window.initStoreLocatorMap();

  // 4. UI Animations & Interactions
  initScrollReveal();
  initCounterAnimation();
  initFAQAccordion();
  initMobileMenu();
  initNewsletterForm();
  initContactForm();
  highlightActiveNavLink();
});

// --- Scroll Reveal Animation ---
function initScrollReveal() {
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');

  const revealCallback = (entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        observer.unobserve(entry.target);
      }
    });
  };

  const observer = new IntersectionObserver(revealCallback, {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  });

  revealElements.forEach(el => observer.observe(el));
}

// --- Counter Animation ---
function initCounterAnimation() {
  const counters = document.querySelectorAll('.counter-box');
  if (counters.length === 0) return;

  const countCallback = (entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const counter = entry.target;
        const targetNumber = Number(counter.getAttribute('data-target')) || 0;
        const duration = 2000;
        const stepTime = Math.abs(Math.floor(duration / (targetNumber || 100)));
        let current = 0;
        const increment = Math.max(1, Math.floor(targetNumber / 60));

        const timer = setInterval(() => {
          current += increment;
          if (current >= targetNumber) {
            current = targetNumber;
            clearInterval(timer);
          }
          counter.textContent = current.toLocaleString();
        }, 30);

        observer.unobserve(counter);
      }
    });
  };

  const observer = new IntersectionObserver(countCallback, { threshold: 0.5 });
  counters.forEach(c => observer.observe(c));
}

// --- FAQ Accordion ---
function initFAQAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const header = item.querySelector('.faq-header');
    if (header) {
      header.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        faqItems.forEach(i => i.classList.remove('active'));
        if (!isActive) {
          item.classList.add('active');
        }
      });
    }
  });
}

// --- Mobile Hamburger Menu ---
function initMobileMenu() {
  const hamburgerBtn = document.getElementById('hamburger-btn');
  const navLinks = document.getElementById('nav-links');
  if (!hamburgerBtn || !navLinks) return;

  hamburgerBtn.addEventListener('click', () => {
    navLinks.classList.toggle('mobile-open');
    const isOpen = navLinks.classList.contains('mobile-open');
    hamburgerBtn.innerHTML = isOpen ? '✕' : '☰';
  });

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (!hamburgerBtn.contains(e.target) && !navLinks.contains(e.target)) {
      navLinks.classList.remove('mobile-open');
      hamburgerBtn.innerHTML = '☰';
    }
  });
}

// --- Newsletter Subscription (UI only) ---
function initNewsletterForm() {
  const forms = document.querySelectorAll('.newsletter-form');
  forms.forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = form.querySelector('input[type="email"]');
      if (input && input.value.trim()) {
        if (window.showToast) {
          showToast(`Welcome to the Luxe Circle, ${input.value.trim()}!`, 'success');
        }
        input.value = '';
      }
    });
  });
}

// --- Contact Form (UI only) ---
function initContactForm() {
  const form = document.getElementById('boutique-contact-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (window.showToast) {
      showToast('Thank you for contacting Luxe Boutique. An ambassador will reach out within 24 hours.', 'success');
    }
    form.reset();
  });
}

// --- Highlight Active Nav Link ---
function highlightActiveNavLink() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;

    if (currentPath.endsWith(href) || (currentPath === '/' && href === 'index.html')) {
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    }
  });
}
