/**
 * ============================================================
 * LUXE BOUTIQUE - SHOPPING CART (localStorage & Cart Page UI)
 * ============================================================
 */

const CART_KEY = 'luxe_cart';
const TAX_RATE = 0.08; // 8% sales tax
const DEFAULT_SHIPPING = 15.00;
const FREE_SHIPPING_THRESHOLD = 250.00;

function getCart() {
  const data = localStorage.getItem(CART_KEY);
  return data ? JSON.parse(data) : [];
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}

// Update navbar cart badge count
function updateCartBadge() {
  const cart = getCart();
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const badges = document.querySelectorAll('.cart-badge');
  badges.forEach(b => {
    b.textContent = totalCount;
  });
}

// Add item to cart
function addToCart(productId, quantity = 1, size = null, color = null) {
  const products = window.boutiqueProducts || [];
  const product = products.find(p => p.id === Number(productId));
  if (!product) return;

  const defaultSize = size || (product.sizes && product.sizes[0]) || 'Standard';
  const defaultColor = color || (product.colors && product.colors[0] && product.colors[0].name) || 'Default';

  const cart = getCart();
  const existingIndex = cart.findIndex(
    item => item.id === product.id && item.size === defaultSize && item.color === defaultColor
  );

  if (existingIndex > -1) {
    cart[existingIndex].quantity += quantity;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      size: defaultSize,
      color: defaultColor,
      quantity: quantity
    });
  }

  saveCart(cart);
  if (window.showToast) {
    showToast(`Added "${product.name}" to cart`, 'cart');
  }
}

// Remove item from cart
function removeFromCart(index) {
  const cart = getCart();
  if (index >= 0 && index < cart.length) {
    const removedName = cart[index].name;
    cart.splice(index, 1);
    saveCart(cart);
    if (window.showToast) {
      showToast(`Removed "${removedName}" from cart`, 'info');
    }
    renderCartPage();
  }
}

// Increase / decrease quantity
function updateCartQuantity(index, change) {
  const cart = getCart();
  if (index >= 0 && index < cart.length) {
    cart[index].quantity += change;
    if (cart[index].quantity < 1) {
      cart[index].quantity = 1;
    }
    saveCart(cart);
    renderCartPage();
  }
}

// Render Cart Page
function renderCartPage() {
  const cartContainer = document.getElementById('cart-items-container');
  const emptyStateEl = document.getElementById('cart-empty-state');
  const cartContentLayout = document.getElementById('cart-content-layout');
  const subtotalEl = document.getElementById('cart-subtotal');
  const taxEl = document.getElementById('cart-tax');
  const shippingEl = document.getElementById('cart-shipping');
  const totalEl = document.getElementById('cart-grand-total');

  if (!cartContainer) return; // Not on Cart page

  const cart = getCart();

  if (cart.length === 0) {
    if (cartContentLayout) cartContentLayout.style.display = 'none';
    if (emptyStateEl) emptyStateEl.style.display = 'block';
    return;
  }

  if (cartContentLayout) cartContentLayout.style.display = 'grid';
  if (emptyStateEl) emptyStateEl.style.display = 'none';

  let subtotal = 0;
  cartContainer.innerHTML = '';

  cart.forEach((item, index) => {
    const itemSubtotal = item.price * item.quantity;
    subtotal += itemSubtotal;

    const row = document.createElement('div');
    row.className = 'cart-item-row animate-fade-in';
    row.innerHTML = `
      <img src="${item.image}" alt="${item.name}" class="cart-item-img" />
      <div class="cart-item-info">
        <h4 class="cart-item-title">${item.name}</h4>
        <p class="cart-item-meta">Size: <strong>${item.size}</strong> | Color: <strong>${item.color}</strong></p>
        <p class="cart-item-price" style="margin-top: 6px;">₹${item.price.toFixed(2)}</p>
      </div>
      <div class="qty-selector">
        <button class="qty-btn" onclick="updateCartQuantity(${index}, -1)" aria-label="Decrease quantity">−</button>
        <span class="qty-value">${item.quantity}</span>
        <button class="qty-btn" onclick="updateCartQuantity(${index}, 1)" aria-label="Increase quantity">+</button>
      </div>
      <div style="text-align: right; min-width: 90px;">
        <p style="font-weight: 700; font-size: 1.1rem; color: var(--color-black);">₹${itemSubtotal.toFixed(2)}</p>
      </div>
      <button class="btn-remove-item" onclick="removeFromCart(${index})" title="Remove item" aria-label="Remove item">
        ✕
      </button>
    `;
    cartContainer.appendChild(row);
  });

  // Calculations
  const tax = subtotal * TAX_RATE;
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : DEFAULT_SHIPPING;
  const grandTotal = subtotal + tax + shipping;

  if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
  if (taxEl) taxEl.textContent = `₹${tax.toFixed(2)}`;
  if (shippingEl) {
    shippingEl.textContent = shipping === 0 ? 'FREE' : `₹${shipping.toFixed(2)}`;
    if (shipping === 0) shippingEl.style.color = '#25d366';
    else shippingEl.style.color = 'inherit';
  }
  if (totalEl) totalEl.textContent = `₹${grandTotal.toFixed(2)}`;
}

// Checkout Modal UI
function openCheckoutModal() {
  const cart = getCart();
  if (cart.length === 0) {
    if (window.showToast) showToast('Your shopping cart is empty', 'error');
    return;
  }
  const overlay = document.getElementById('checkout-modal-overlay');
  if (overlay) overlay.classList.add('active');
}

function closeCheckoutModal() {
  const overlay = document.getElementById('checkout-modal-overlay');
  if (overlay) overlay.classList.remove('active');
}

function handleCheckoutSubmit(e) {
  e.preventDefault();
  closeCheckoutModal();
  localStorage.setItem(CART_KEY, JSON.stringify([]));
  updateCartBadge();
  renderCartPage();
  if (window.showToast) {
    showToast('Order placed successfully! Thank you for choosing Luxe Boutique.', 'cart');
  }
}

// Expose globally
window.getCart = getCart;
window.saveCart = saveCart;
window.updateCartBadge = updateCartBadge;
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartQuantity = updateCartQuantity;
window.renderCartPage = renderCartPage;
window.openCheckoutModal = openCheckoutModal;
window.closeCheckoutModal = closeCheckoutModal;
window.handleCheckoutSubmit = handleCheckoutSubmit;
